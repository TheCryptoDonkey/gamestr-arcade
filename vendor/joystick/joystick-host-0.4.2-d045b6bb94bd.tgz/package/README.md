# @forgesworn/joystick-host

Browser-side WebSocket client for the joystick phone-as-controller SDK. Game-agnostic, callback-based — your game does the slot→action mapping.

## Usage

### Single-player

```ts
import { startControllerHost } from '@forgesworn/joystick-host';

const host = startControllerHost({
  ws: 'wss://controller.example.app/',
});

host.setSpec({
  name: 'My Game',
  version: 1,
  slots: {
    joyL: { mode: 'heading', tapAction: 'A' },
    A: { icon: 'X', label: 'FIRE', colour: '#f80' },
  },
});

host.onPlayerJoin((p) => console.log('player joined', p.p));
host.onPlayerLeave((p) => console.log('player left', p.p));
host.onInput((frame) => {
  if (frame.k === 'A') setFire(frame.v === '1');
  else if (frame.k === 'joyL') setHeading(parseInt(frame.v, 10) / 1000);
});

// Show the QR code:
renderQR(host.pairingUrl);
```

### Multi-player

Pass `multi: true` to opt the broker into multi-player mode. Up to 8 phones can pair, each assigned a player slot 0..7.

```ts
const host = startControllerHost({
  ws: 'wss://controller.example.app/',
  multi: true,
});

host.onPlayerJoin((p) => spawnTankForPlayer(p.p));
host.onPlayerLeave((p) => removeTank(p.p));

host.onInput((frame) => {
  // frame.p is the player slot in multi mode (undefined in single).
  const tank = tankForPlayer(frame.p ?? 0);
  if (frame.k === 'A') tank.fire = frame.v === '1';
});

// Address a single phone (e.g. show "you won!" on the loser's pad):
host.sendToPlayer(2, { type: 'haptic', pattern: 'tap' });

// Broadcast to all:
host.broadcast({ type: 'controller-spec', spec: newSpec });
```

## Pairing URL

`host.pairingUrl` is the URL you encode into a QR. It contains the session id and (if non-default) the WS endpoint. By default it points at `/controller` on the current origin — pass `pwaUrl` to override:

```ts
const host = startControllerHost({
  pwaUrl: 'https://pad.forgesworn.dev',
});
// → "https://pad.forgesworn.dev/?s=<sessionId>&v=2"
```

`encodePairingUrl` and `decodePairingUrl` are exported as separate helpers for callers that want to render their own pairing UI.

## Host ownership and migration

0.2.0 defaults to `protocolVersion: 2` and a six-letter controller code. The SDK creates a random 256-bit `hostToken`, sends it in its first WebSocket frame and waits for the broker's `host-ready` acknowledgement. The pairing URL and Foregather invitation carry `v=2` and never carry the host credential. Another client with the visible controller code cannot replace this host.

The credential remains private to this host instance and survives its socket reconnects. An application that deliberately restores a host may supply the same `hostToken`; treat it as a secret. A full page reload normally creates a new session. Custom v2 session IDs must contain at least six characters. The broker retains ownership for five minutes after the session becomes empty, then permits code reuse.

Set `protocolVersion: 1` for an older broker/client integration. It uses a separate namespace and the legacy four-letter default; it has no v2 ownership guarantee. Preserve `version` when parsing, storing or transferring pairing tokens. Versionless links select legacy sessions.

## Nostr signer relay

An announced identity does not establish signing authority. A connected phone
must explicitly announce `caps.canSignEvents: true` and install an authorised
`onSignRequest` handler in its embedding app. Joystick Pad currently announces
identity only, so it advertises `canSignEvents: false`.

The host must supply a verifier that checks the NIP-01 event id and Schnorr
signature. For example, an application already using `nostr-tools` can pass its
`verifyEvent`; the host and mobile SDKs carry no Nostr runtime dependency:

```ts
import { verifyEvent } from 'nostr-tools/pure';
import { startControllerHost } from '@forgesworn/joystick-host';

const host = startControllerHost({ verifyEvent });

host.onSigner((p, signer) => {
  if (signer) console.log(`p${p} announced ${signer.npub}`);
});

const event = await host.signEvent({ kind: 1, content: 'gg' }, /* p= */ 0);
```

`signEvent` captures the requested player's announced pubkey and copies the
template. Omitted tags become `[]` and an omitted `created_at` is resolved on the
host before sending. Replies must match that player, pubkey, kind, content,
ordered tags and timestamp, and the supplied verifier must return `true`.
Neither later template edits nor a reply from another player can change a
pending request. Disconnect, signer revocation or signing authority changes
invalidate that player's pending requests, including replies undergoing async
verification.

`signEvent` rejects with `no-pair`, `no-signer`, `no-signature-verifier`,
`sign-timeout`, or `sign-failed: <msg>`. A missing verifier, failed verification
or verifier exception never returns an event. Verifiers must check both event
hash and signature; a shape-only check is insufficient. See
[NIP-01](https://github.com/nostr-protocol/nips/blob/master/01.md) for the event
format and signature rules.

## Environment

Defaults to `globalThis.WebSocket` and `globalThis.setTimeout`. Pass `WebSocketImpl` / `setTimeoutImpl` via options for Node tests.

## Stage

Consumed by the Tank, Quiz and Tilt applications. The package remains private pending the separate public-release checklist.
